 <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit extends CI_Controller {
    
        public function delete_task($id)
        {
            $this->edit_model->delete_task($id);
            redirect('jobstatus');
        }

        public function edit_jobstatus($id)
        {
            $data['item'] = $this->pages_model->get_task($id);

        if (empty($data['item']))
        {
                show_404();
        }

        $data['title'] = 'Edit task';

        $this->load->view('templates/header', $data);
        $this->load->view('pages/edit_jobstatus', $data);
        $this->load->view('templates/footer');
        }

        public function update_jobstatus()
        {
           $this->edit_model->update_jstat();
           redirect('jobstatus');
        }
    
        
    }
    