<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Create extends CI_Controller
{

    /* public function addcustomer()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Text', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === false) {
            $this->load->view('templates/header', $data);
            $this->load->view('pages/addcustomer');
            $this->load->view('templates/footer');

        } else {
            $this->create_model->add_customer();
            //$this->load->view('news/success');
            die("SUCCESS");
        }
    } */

    public function add_vechel()
    {
        if (!file_exists(APPPATH . 'views/pages/addvechel.php')) {
            show_404();
        }
        $data['title'] = ucfirst('add Vechel');
        $this->form_validation->set_rules('plateno', 'plate No', 'required');
        $this->form_validation->set_rules('owner', 'Owner', 'required');
        $this->form_validation->set_rules('carname', 'car name', 'required');
        $this->form_validation->set_rules('make', 'make', 'required');
        $this->form_validation->set_rules('year', 'year', 'required');
        $this->form_validation->set_rules('mileage', 'mileage', 'required');
        $this->form_validation->set_rules('color', 'color', 'required');
        $this->form_validation->set_rules('entrydate', 'date of enty', 'required');
        $this->form_validation->set_rules('exitdate', 'date of exit', 'required');
        $this->form_validation->set_rules('compliant', 'compliant', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('pages/addvechel');
            $this->load->view('templates/footer');
        } else {
            $this->create_model->set_car();

            redirect('viewvechel');
        }

    }
    public function add_customer()
    {
        if (!file_exists(APPPATH . 'views/pages/addcustomer.php')) {
            show_404();
        }

        $data['title'] = ucfirst('add customer');

        $this->form_validation->set_rules('name', 'customer name', 'required');
        $this->form_validation->set_rules('address', 'address', 'required');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        if ($this->form_validation->run() == false) {
           
            $this->load->view('templates/header', $data);
            $this->load->view('pages/addcustomer');
            $this->load->view('templates/footer');
        } else {
            $this->create_model->set_customer();

            redirect('viewcustomer');
        }

    }
    public function add_employee()
    {

        $data['title'] = ucfirst('add employee');
        $this->form_validation->set_rules('name', 'employee name', 'required');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('senioritydate', 'seniority date', 'required');
        $this->form_validation->set_rules('dateofbirth', 'date of birth', 'required');
        $this->form_validation->set_rules('gender', 'gender', 'required');
        $this->form_validation->set_rules('department', 'department', 'required');
        $this->form_validation->set_rules('speciality', 'Speciality', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('pages/addemployee');
            $this->load->view('templates/footer');
        } else {
            $this->create_model->set_employee();

           redirect('viewemployee');
        }

        // if ( ! file_exists(APPPATH.'views/manger/add_employee.php'))
        // {
        //         // Whoops, we don't have a page for that!
        //         show_404();
        // }

        // $this->load->view('manger/add_employee');

    }
    public function add_stock()
    {
        $data['title'] = ucfirst('add part');
        $this->form_validation->set_rules('partno', 'part_no', 'required');
        $this->form_validation->set_rules('partname', 'part_name', 'required');
        $this->form_validation->set_rules('purchasedate', 'date of purchase', 'required');
        $this->form_validation->set_rules('brand', 'brand', 'required');
        $this->form_validation->set_rules('quantity', 'quantity', 'required');
        $this->form_validation->set_rules('price', 'price', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('pages/addstock');
            $this->load->view('templates/footer');
        } else {
            $this->create_model->set_part();

            redirect('viewstock');
        }

        // if ( ! file_exists(APPPATH.'views/manger/add_stock.php'))
        // {
        //          show_404();
        // }

        // $this->load->view('manger/add_stock');

    }

    public function assign_job()
    {
        if (!file_exists(APPPATH . 'views/pages/assignjob.php')) {
            show_404();
        }
        
        $data['title'] = ucfirst('assign job');
        $this->form_validation->set_rules('servicetype', 'service name', 'required');
        $this->form_validation->set_rules('plateno', 'Plate number', 'required');
        $this->form_validation->set_rules('partused', 'Part used', 'required');
        $this->form_validation->set_rules('technician', 'Technician id', 'required');
        $this->form_validation->set_rules('taskstatus', 'Task status', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('pages/assignjob');
            $this->load->view('templates/footer');
        } else {
            
            $this->create_model->set_task();

            redirect('jobstatus');
        }

    }

    public function update_stock()
    {
        if (!file_exists(APPPATH . 'views/manger/update_emp_info.php')) {
            show_404();
        }

        $this->load->view('manger/update_emp_info');

    }
    

    
}
