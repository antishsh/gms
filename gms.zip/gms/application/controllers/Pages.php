<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pages extends CI_Controller
{

    public function view($page = 'dashboard')
    {
        if (!file_exists(APPPATH . 'views/pages/' . $page . '.php')) {
            // Whoops, we don't have a page for that!
            show_404();
        }

        $data['title'] = ucfirst($page); // Capitalize the first letter
        $data['cars'] = $this->pages_model->get_vechel();
        $data['customers'] = $this->pages_model->get_customer();
        $data['tasks'] = $this->pages_model->get_task();
        $data['employee'] = $this->pages_model->get_employee();
        $data['parts'] = $this->pages_model->get_part();
        $data['records'] = $this->pages_model->get_service();
        $data['department'] = $this->pages_model->get_department();

        $this->load->view('templates/header', $data);
        $this->load->view('pages/' . $page, $data);
        $this->load->view('templates/footer', $data);
    }
    public function view_vechel()
    {
        if (!file_exists(APPPATH . 'views/pages/viewvechel.php')) {
            show_404();
        }
        $this->pages_model->get_vechel();
        
       

    }
    public function view_customer()
    {
        $query = $this->db->get("customer");
        return $query->result_array();

    }
    public function job_status()
    {
        if (!file_exists(APPPATH . 'views/pages/jobstatus.php')) {
            show_404();
        }
        $query = $this->db->get("task");
        return $query->result_array();

    }
    public function view_emp()
    {
        if (!file_exists(APPPATH . 'views/pages/viewemployee.php')) {
            show_404();
        }

        $query = $this->db->get("employee");
        return $query->result_array();

    }
    public function view_stock()
    {
        if (!file_exists(APPPATH . 'views/pages/viewstock.php')) {
            show_404();
        }
        $query = $this->db->get("part");
        return $query->result_array();

    }

    public function get_service()
    {

        $query = $this->db->get("service");
        return $query->result_array();

    }
    public function get_department()
    {

        $query = $this->db->get("department");
        return $query->result_array();

    }

    

    
   

}
