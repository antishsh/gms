    </main>
    </div>
    </div>

    <script type="text/javascript">
var foopicker = new FooPicker({
    id: 'datepicker',
    dateFormat: 'yyyy/MM/dd'
});
var foopicker2 = new FooPicker({
    id: 'datepicker2',
    dateFormat: 'yyyy/MM/dd'
});
    </script>

    <script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <!-- <script>window.jQuery || document.write('<script src="<?php echo base_url(); ?>assets/js/jquery-slim.min.js"><\/script>')</script><script src="/docs/4.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script> -->
    <script src="<?php echo base_url(); ?>assets/js/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <script src="<?php echo base_url(); ?>assets/js/feather.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/foopicker.js"></script>

    </body>

    </html>