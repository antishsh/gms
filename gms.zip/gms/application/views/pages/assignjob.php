<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Asign Job</h3>
        </div>
        <div class="card-body">
        <?php echo validation_errors(); ?>
        <?php echo form_open('create/assign_job'); ?>
                <fieldset>

                    <div class="form-group">
                        <label for="exampleSelect1">Service Type</label>
                        <select class="form-control" name="servicetype">
                            <option></option>
                            <?php
                                foreach ($records as $r) {echo " <option>" . $r['service_name'] . " <option>";}
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleSelect1">Plate No</label>
                        <select class="form-control" name="plateno" placeholder="choose">
                            <option></option>
                            <?php
                                foreach ($tasks as $r) {echo " <option>" . $r['plate_no'] . " <option>";}
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleSelect1">Part Used</label>
                        <select class="form-control" name="partused">
                            <option></option>
                            <?php
                                foreach ($parts as $r) {echo " <option>" . $r['part_no'] . " <option>";}
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleSelect1">Technician</label>
                        <select class="form-control" name="technician">
                            <option></option>
                            <?php
                                foreach ($employee as $r) {echo " <option>" . $r['employee_name'] . " <option>";}
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleSelect1">Task Status</label>
                        <select class="form-control" name="taskstatus">
                            <option></option>
                            <option>On progres</option>
                            <option>Finished</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </fieldset>
            </form>
        </div>
    </div>

    <!-- Latest Users -->

</div>
</div>

</section>