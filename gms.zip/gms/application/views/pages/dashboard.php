<div class="col-md-9">
    <!-- Website Overview -->
    <i class="fas fa-camera"></i> <!-- this icon's 1) style prefix == fas and 2) icon name == camera -->
<i class="fas fa-camera"></i> <!-- using an <i> element to reference the icon -->
<span class="fas fa-camera"></span> <!-- using a <span> element to reference the icon -->
    <!-- Latest Users -->

</div>
</div>

</section>