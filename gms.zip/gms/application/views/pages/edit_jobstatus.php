<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Update Task</h3>
        </div>
        <div class="card-body">
            <?php echo validation_errors(); ?>
            <?php echo form_open('edit/update_jobstatus'); ?>
            <fieldset>
                <input type="hidden" name="id" value="<?php echo $item['task_id']; ?>">
                <div class="form-group">
                    <label for="exampleSelect1">Service Type</label>
                    <input type="text" class="form-control" name="servicetype" value="<?php echo $item['service_name']; ?>">
                </div>
                <div class="form-group">
                    <label for="exampleSelect1">Plate No</label>
                    <input type="text" class="form-control" name="plateno" placeholder="choose" value="<?php echo $item['plate_no']; ?>">
                </div>
                <div class="form-group">
                    <label for="exampleSelect1">Part Used</label>
                    <input type="text" class="form-control" name="partused" value="<?php echo $item['part_used']; ?>">

                </div>
                <div class="form-group">
                    <label for="exampleSelect1">Technician</label>
                    <input type="text" class="form-control" name="technician" value="<?php echo $item['technician']; ?>">

                </div>
                <div class="form-group">
                    <label for="exampleSelect1">Task Status</label>
                    <input type="text" class="form-control" name="taskstatus"
                        value="<?php echo $item['task_status']; ?>">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </fieldset>
            </form>
        </div>
    </div>

    <!-- Latest Users -->

</div>
</div>

</section>