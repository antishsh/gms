<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Add Part</h3>
        </div>
        <div class="card-body">
        <?php echo validation_errors(); ?>
        <?php echo form_open('create/add_stock'); ?>
                <fieldset>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Part No</label>
                        <input type="text" class="form-control" name="partno" placeholder="Enter Part No">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Part Name</label>
                        <input type="text" class="form-control" name="partname" placeholder="Enter Part Name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Date of Purchase</label>
                        <input type="text" class="form-control" name="purchasedate" id="datepicker">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Brand</label>
                        <input type="text" class="form-control" name="brand" placeholder="Enter Brand">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Quantity</label>
                        <input type="text" class="form-control" name="quantity" placeholder="Enter Quantity">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Price</label>
                        <input type="text" class="form-control" name="price" placeholder="Enter Price">
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </fieldset>
            </form>
        </div>
    </div>

    <!-- Latest Users -->

</div>
</div>

</section>