<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Customer List</h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>

                        <th>customer_id</th>
                        <th>customer_name</th>
                        <th>addres</th>
                        <th>phone</th>
                        <th>email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php foreach ($customers as $r) 
                    {
                        echo "<tr >";
                        echo " <td>" . $r['customer_id'] . " </td>";
                        echo " <td>" . $r['customer_name'] . " </td>";
                        echo " <td>" . $r['addres'] . " </td>";
                        echo " <td>" . $r['phone'] . " </td>";
                        echo " <td>" . $r['email'] . " </td>";
                        echo "<td> <button type=\"button\" class=\"btn btn-outline-warning btn-sm\">update</button>
                            <button type=\"button\" class=\"btn btn-outline-danger btn-sm\">Delete</button></td>";
                        echo "</tr >";
                    }
                    
                    ?>
                        
                        
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Latest Users -->

</div>
</div>

</section>