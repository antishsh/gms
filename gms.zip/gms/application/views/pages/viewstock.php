<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Part List</h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>

                        <th>part_no</th>
                        <th>part_name</th>
                        <th>date_of_purchase</th>
                        <th>brand</th>
                        <th>quantity</th>
                        <th>price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($parts as $r) 
                    {
                        echo "<tr >";
                        echo " <td>" . $r['part_no'] . " </td>";
                        echo " <td>" . $r['part_name'] . " </td>";
                        echo " <td>" . $r['date_of_purchase'] . " </td>";
                        echo " <td>" . $r['brand'] . " </td>";
                        echo " <td>" . $r['quantity'] . " </td>";
                        echo " <td>" . $r['price'] . " </td>";
                        echo "<td> <button type=\"button\" class=\"btn btn-outline-warning btn-sm\">update</button>
                            <button type=\"button\" class=\"btn btn-outline-danger btn-sm\">Delete</button></td>";
                        echo "</tr >";
                    }
                    
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Latest Users -->

</div>
</div>

</section>