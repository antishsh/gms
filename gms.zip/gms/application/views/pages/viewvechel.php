<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Customer List</h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>

                        <th>plate no</th>
                        <th>Customer name</th>
                        <th>car name</th>
                        <th>make</th>
                        <th>year</th>
                        <th>mileage</th>
                        <th>color</th>
                        <th>date of enty</th>
                        <th>date of exit</th>
                        <th>compliant</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($cars as $r) 
                    {
                        echo "<tr >";
                        echo " <td>" . $r['plate_no'] . " </td>";
                        echo " <td>" . $r['owner'] . " </td>";
                        echo " <td>" . $r['car_name'] . " </td>";
                        echo " <td>" . $r['make'] . " </td>";
                        echo " <td>" . $r['year'] . " </td>";
                        echo " <td>" . $r['mileage'] . " </td>";
                        echo " <td>" . $r['color'] . " </td>";
                        echo " <td>" . $r['date_of_enty'] . " </td>";
                        echo " <td>" . $r['date_of_exit'] . " </td>";
                        echo " <td>" . $r['compliant'] . " </td>";
                        echo "<td> <button type=\"button\" class=\"btn btn-outline-warning btn-sm\">update</button>
                            <button type=\"button\" class=\"btn btn-outline-danger btn-sm\">Delete</button></td>";
                        echo "</tr >";
                    }
                    
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Latest Users -->

</div>
</div>

</section>