<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Edit Employee</h3>
        </div>
        <div class="card-body">
            <?php echo validation_errors(); ?>
            <?php echo form_open('create/add_employee'); ?>
            <fieldset>
                <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter name">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Phone</label>
                    <input type="text" class="form-control" name="phone" placeholder="Enter Phone">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" name="email" aria-describedby="emailHelp"
                        placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone
                        else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Seniority Date</label>
                    <input type="text" class="form-control" name="senioritydate" id="datepicker">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Date of Birth</label>
                    <input type="text" class="form-control" name="dateofbirth" id="datepicker2">
                </div>
                <fieldset class="form-group">
                    <legend>Gender</legend>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="gender" id="optionsRadios1" value="Male"
                                checked="">
                            Male
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="gender" id="optionsRadios2"
                                value="Female">
                            Female
                        </label>
                    </div>

                </fieldset>
                <div class="form-group">
                    <label for="exampleSelect1">Speciality</label>
                    <select class="form-control" name="speciality">
                        <option></option>
                        <?php
                                foreach ($department as $r) {echo " <option>" . $r['department_name'] . " <option>";}
                            ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exampleSelect1">Department</label>
                    <select class="form-control" name="department">
                        <option></option>
                        <?php
                                foreach ($department as $r) {echo " <option>" . $r['department_name'] . " <option>";}
                            ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-warning">Update</button>
                <button type="submit" class="btn btn-info">Cancel</button>
            </fieldset>
            </form>
        </div>
    </div>

    <!-- Latest Users -->

</div>
</div>

</section>