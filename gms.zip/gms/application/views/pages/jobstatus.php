<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary ">
        <div class="card-header">
            <h3>Add Vehecel</h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>

                        <th scope="col">task_id</th>
                        <th scope="col">service_name</th>
                        <th scope="col">plate_no</th>
                        <th scope="col">part_used</th>
                        <th scope="col">technician_id</th>
                        <th scope="col">task_status</th>
                        <th scope="col">Action</th>

                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $r): ?>

                    <tr>
                        <td> <?= $r['task_id']; ?> </td>
                        <td> <?= $r['service_name']; ?> </td>
                        <td> <?= $r['plate_no']; ?> </td>
                        <td> <?= $r['part_used']; ?> </td>
                        <td> <?= $r['technician']; ?> </td>
                        <td> <?= $r['task_status']; ?> </td>
                        <td>
                            <a href="<?php echo base_url(); ?>edit/edit_jobstatus/<?=$r['task_id'] ?>" class="btn btn-outline-warning btn-sm">edit</a>
                            <a href="<?php echo base_url(); ?>edit/delete_task/<?=$r['task_id'] ?>" class="btn btn-outline-danger btn-sm">Delete</a>
                        <td>

                    </tr>
                    <?php endforeach; ?>



                </tbody>
            </table>
        </div>
    </div>
    <!-- Latest Users -->

</div>
</div>

</section>