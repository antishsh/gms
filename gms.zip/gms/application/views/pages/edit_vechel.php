<div class="col-md-9">
    <!-- Website Overview -->
    <div class="card border-secondary mb-3">
        <div class="card-header">
            <h3>Edit Vehecel</h3>
        </div>
        <div class="card-body">
        <?php echo validation_errors(); ?>
        <?php echo form_open('create/add_vechel'); ?>
                <fieldset>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Plate No</label>
                        <input type="text" class="form-control" name="plateno" placeholder="Enter Plate No">
                    </div>
                    <div class="form-group">
                        <label for="exampleSelect1">Owner</label>
                        <select class="form-control" name="owner">
                            <option></option>
                            <?php
                                foreach ($customers as $r) {echo " <option>" . $r['customer_name'] . " <option>";}
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Car Name</label>
                        <input type="text" class="form-control" name="carname" placeholder="Enter Car Name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Make</label>
                        <input type="text" class="form-control" name="make" placeholder="Enter Make">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Year</label>
                        <input type="text" class="form-control" name="year" placeholder="Enter Year">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Date of entry</label>
                        <input type="text" class="form-control" name="entrydate" id="datepicker">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Date of Exit</label>
                        <input type="text" class="form-control" name="exitdate" id="datepicker2">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Mile age</label>
                        <input type="text" class="form-control" name="mileage" placeholder="Enter Mileage">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">color</label>
                        <input type="text" class="form-control" name="color" placeholder="Enter Year">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Compliant</label>
                        <textarea class="form-control" name="compliant" rows="3"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </fieldset>
            </form>
        </div>
    </div>

    <!-- Latest Users -->

</div>
</div>

</section>