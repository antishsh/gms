<?php
class Edit_model extends CI_Model
{

  public function delete_task($id)
  {
      $this->db->where('task_id', $id);
      $this->db->delete('task');
      return true;
  }
  
  public function get_task()
  {
    
  }
  public function update_jstat()
    {
      $data = array(

        'service_name' => $this->input->post('servicetype'),
        'plate_no' => $this->input->post('plateno'),
        'part_used' => $this->input->post('partused'),
        'technician' => $this->input->post('technician'),
        'task_status' => $this->input->post('taskstatus'),
    );
    return $this->db->update('task', $data);
    
    }
}