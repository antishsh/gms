<?php
class Create_model extends CI_Model
{

    public function __construct()
    {
        $this->load->database();
    }

    public function set_task()
    {
        $data = array(

            'service_name' => $this->input->post('servicetype'),
            'plate_no' => $this->input->post('plateno'),
            'part_used' => $this->input->post('partused'),
            'technician' => $this->input->post('technician'),
            'task_status' => $this->input->post('taskstatus'),
        );

        return $this->db->insert('task', $data);
    }

    public function set_service()
    {
        $data = array(
            'service_no' => $this->input->post('service_no'),
            'service_name' => $this->input->post('service_name'),
            'service_price' => $this->input->post('service_price'),
        );
        return $this->db->insert('service', $data);
    }

    public function set_car()
    {
        $data = array(
            'plate_no' => $this->input->post('plateno'),
            'owner' => $this->input->post('owner'),
            'car_name' => $this->input->post('carname'),
            'make' => $this->input->post('make'),
            'year' => $this->input->post('year'),
            'mileage' => $this->input->post('mileage'),
            'color' => $this->input->post('color'),
            'date_of_enty' => $this->input->post('entrydate'),
            'date_of_exit' => $this->input->post('exitdate'),
            'compliant' => $this->input->post('compliant'),
        );
        return $this->db->insert('car', $data);

    }

    public function set_customer()
    {
        $data = array(

            'customer_name' => $this->input->post('name'),
            'addres' => $this->input->post('address'),
            'phone' => $this->input->post('phone'),
            'email' => $this->input->post('email'),

        );
        return $this->db->insert('customer', $data);

    }

    public function set_part()
    {
        $date = '';
        $modefide_date = $this->fixdate($date);

        $data = array(
            'part_no' => $this->input->post('partno'),
            'part_name' => $this->input->post('partname'),
            'date_of_purchase' => $this->input->post('purchasedate'),
            'brand' => $this->input->post('brand'),
            'quantity' => $this->input->post('quantity'),
            'price' => $this->input->post('price'),
        );
        return $this->db->insert('part', $data);

    }
    public function set_employee()
    {
        $data = array(

            'employee_name' => $this->input->post('name'),
            'phone' => $this->input->post('phone'),
            'email' => $this->input->post('email'),
            'seniority_date' => $this->input->post('senioritydate'),
            'date_of_birth' => $this->input->post('dateofbirth'),
            'gender' => $this->input->post('gender'),
            'department' => $this->input->post('department'),
            'title' => $this->input->post('speciality'),
        );
        return $this->db->insert('employee', $data);

    }

    public function set_department()
    {
        $data = array(
            'department_id' => $this->input->post('department_id'),
            'department_name' => $this->input->post('department_name'),
        );
        return $this->db->insert('department', $data);

    }
    public function fixdate($date) {
        return date('y-m-d', strtotime($date));
    }
}
