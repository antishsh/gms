<?php
class Pages_model extends CI_Model
{

    public function get_vechel()
    {
        $query = $this->db->get("car");
        return $query->result_array();
    }
    public function get_customer()
    {
        $query = $this->db->get("customer");
        return $query->result_array();
    }
    public function get_task($id = FALSE)
    {
            if ($id === FALSE)
            {
                $query = $this->db->get("task");
                return $query->result_array();
            }
    
            $query = $this->db->get_where('task', array('task_id' => $id));
            return $query->row_array();
    }
    public function get_employee()
    {
        $query = $this->db->get("employee");
        return $query->result_array();
    }
    public function get_part()
    {
        $query = $this->db->get("part");
        return $query->result_array();
    }
    public function get_service()
    {
        $query = $this->db->get("service");
        return $query->result_array();
    }
    public function get_department()
    {
        $query = $this->db->get("department");
        return $query->result_array();
    }

    //updating

    

    
 

}
