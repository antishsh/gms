-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 04, 2019 at 04:42 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `car_garage`
--

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `id` int(11) NOT NULL,
  `plate_no` varchar(50) NOT NULL,
  `car_name` varchar(50) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `make` varchar(50) NOT NULL,
  `year` int(11) NOT NULL,
  `mileage` int(11) NOT NULL,
  `color` varchar(50) NOT NULL,
  `date_of_enty` date NOT NULL,
  `date_of_exit` date NOT NULL,
  `compliant` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`id`, `plate_no`, `car_name`, `owner`, `make`, `year`, `mileage`, `color`, `date_of_enty`, `date_of_exit`, `compliant`) VALUES
(0, 'wq-2233-343', 'Yaris', 'yeshewas', 'Toyota', 2003, 23223, 'red', '2019-10-11', '2019-10-18', 'i need paint');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` varchar(50) NOT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `plate_no` varchar(50) DEFAULT NULL,
  `addres` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `plate_no`, `addres`, `phone`, `email`) VALUES
('cut_12', 'yeshewas', 'a234567', 'addis', '097866543', 'yes@gmail.com'),
('cut_67', 'bernabas', 'b34567', 'jima', '09567890', 'yes@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`) VALUES
(1, 'Body'),
(2, 'Paint'),
(3, 'Electric'),
(4, 'Engine'),
(5, 'Break');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employe_id` int(11) NOT NULL,
  `employee_name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `seniority_date` date NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `department` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employe_id`, `employee_name`, `phone`, `email`, `seniority_date`, `date_of_birth`, `gender`, `department`, `title`) VALUES
(1, 'anteneh', '09192912312', 'anteneh@gmail.com', '2019-10-19', '2019-10-10', 'Male', 'Electric', 'Electrician');

-- --------------------------------------------------------

--
-- Table structure for table `part`
--

CREATE TABLE `part` (
  `id` int(11) NOT NULL,
  `part_no` varchar(50) NOT NULL,
  `part_name` varchar(50) NOT NULL,
  `date_of_purchase` date NOT NULL,
  `brand` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `part`
--

INSERT INTO `part` (`id`, `part_no`, `part_name`, `date_of_purchase`, `brand`, `quantity`, `price`) VALUES
(1, 'pt-4344e', 'engine', '2019-10-05', 'orlec', 343, 5432);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `service_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `service_name`, `service_price`) VALUES
(1, 'body', 1000),
(2, 'engine overhaull', 10000),
(3, 'electric', 200),
(4, 'labiajo', 150),
(5, 'break', 600),
(6, 'inspection', 200);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `task_id` int(11) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `plate_no` varchar(50) NOT NULL,
  `part_used` varchar(50) NOT NULL,
  `technician` varchar(50) NOT NULL,
  `task_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`task_id`, `service_name`, `plate_no`, `part_used`, `technician`, `task_status`) VALUES
(2, 'wash ', 'b34567', 'oile', 'emp_34', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'anteneh', '12132', 'antenehshimelis2019@gmail.com', 'antish', '81dc9bdb52d04dc20036dbd8313ed055', '2019-09-27 07:49:01'),
(0, 'barni', '1213', 'antenehshimelis43@gmail.com', 'barni', '81dc9bdb52d04dc20036dbd8313ed055', '2019-09-29 13:17:37'),
(0, 'hiwi', '12132', 'antenehshimelis26@gmail.com', 'hiwi', 'e2fc714c4727ee9395f324cd2e7f331f', '2019-09-29 13:26:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `FK` (`plate_no`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employe_id`),
  ADD KEY `FK` (`department`);

--
-- Indexes for table `part`
--
ALTER TABLE `part`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `FK` (`service_name`,`plate_no`,`part_used`,`technician`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `part`
--
ALTER TABLE `part`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
