-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 03, 2019 at 04:38 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `car_garage`
--

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `plate_no` varchar(50) NOT NULL,
  `car_name` varchar(50) DEFAULT NULL,
  `make` varchar(50) DEFAULT NULL,
  `year` date DEFAULT NULL,
  `mileage` int(11) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `date_of_enty` date DEFAULT NULL,
  `date_of_exit` date DEFAULT NULL,
  `compliant` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` varchar(50) NOT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `plate_no` varchar(50) DEFAULT NULL,
  `addres` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `plate_no`, `addres`, `phone`, `email`) VALUES
('cut_12', 'yeshewas', 'a234567', 'addis', '097866543', 'yes@gmail.com'),
('cut_67', 'bernabas', 'b34567', 'jima', '09567890', 'yes@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` varchar(50) NOT NULL,
  `department_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employe_id` varchar(50) NOT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `seniority_date` date DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employe_id`, `employee_name`, `phone`, `email`, `seniority_date`, `date_of_birth`, `gender`, `department`, `title`) VALUES
('123', 'anteneh', '09192912312', 'antenehshimelis2019@gmail.com', '0000-00-00', '0000-00-00', 'male', 'electritian', 'cadilak'),
('emp', 'antene', '09238221', 'antenehshimelis2019@gmail.com', '2019-12-02', '2012-04-08', 'male', 'electritian', 'Senior tech'),
('emp_02', 'yeshewas', '09876543', 'yes@gmail.com', '2019-09-03', '2019-09-01', 'male', 'ennginnering', 'mechanic'),
('emp_1', 'bernabas', '0911345678', 'bar@gmail.com', '2019-08-04', '2019-06-02', 'male', 'electric', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `part`
--

CREATE TABLE `part` (
  `part_no` varchar(50) NOT NULL,
  `part_name` varchar(50) DEFAULT NULL,
  `date_of_purchase` date DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `part`
--

INSERT INTO `part` (`part_no`, `part_name`, `date_of_purchase`, `brand`, `quantity`, `price`) VALUES
('pt_09', 'light', '2019-09-03', 'romel', 12, 350),
('pt_13', 'oile', '2019-09-04', 'delox', 5, 850);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_no` varchar(50) NOT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `service_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_no`, `service_name`, `service_price`) VALUES
('se_01', 'oil change', 200),
('se_02', 'paint', 1500),
('se_03', 'body', 1000),
('se_04', 'engine overhaull', 10000),
('se_05', 'electric', 200),
('se_06', 'labiajo', 150);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `task_id` int(50) NOT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `plate_no` varchar(50) DEFAULT NULL,
  `part_used` varchar(50) DEFAULT NULL,
  `technician_id` varchar(50) DEFAULT NULL,
  `task_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`task_id`, `service_name`, `plate_no`, `part_used`, `technician_id`, `task_status`) VALUES
(1, 'oile change', 'b45634', 'oile', 'emp_45', 'open'),
(2, 'wash', 'b34567', 'oile', 'emp_34', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'anteneh', '12132', 'antenehshimelis2019@gmail.com', 'antish', '81dc9bdb52d04dc20036dbd8313ed055', '2019-09-27 07:49:01'),
(0, 'barni', '1213', 'antenehshimelis43@gmail.com', 'barni', '81dc9bdb52d04dc20036dbd8313ed055', '2019-09-29 13:17:37'),
(0, 'hiwi', '12132', 'antenehshimelis26@gmail.com', 'hiwi', 'e2fc714c4727ee9395f324cd2e7f331f', '2019-09-29 13:26:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`plate_no`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `FK` (`plate_no`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employe_id`),
  ADD KEY `FK` (`department`);

--
-- Indexes for table `part`
--
ALTER TABLE `part`
  ADD PRIMARY KEY (`part_no`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_no`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `FK` (`service_name`,`plate_no`,`part_used`,`technician_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `task_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
